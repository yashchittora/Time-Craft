# Time-Craft
## A Minimalistic and Beautiful Clock Widget for macOS

## Works With Ubersicht

### It is made with CoffeeScript that follows simple HTML , CSS and Javascript logic
### Hence it is fully customizable :)
Here are two layouts
Just toggle between the true false settings in the code.

Thank You !!!

<img width="1440" alt="Screenshot 2023-12-30 at 2 32 23 PM" src="https://github.com/yashchittora/Time-Craft/assets/112685991/d5aeebda-8678-487c-b1d0-13743a3b0e93">
<img width="1440" alt="Screenshot 2023-12-30 at 2 32 11 PM" src="https://github.com/yashchittora/Time-Craft/assets/112685991/2c60b9c9-97e6-4917-b601-8e715e5cb2ed">
